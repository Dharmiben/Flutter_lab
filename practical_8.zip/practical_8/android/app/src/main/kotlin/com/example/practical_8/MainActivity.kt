package com.example.practical_8

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
