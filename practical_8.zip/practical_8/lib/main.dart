import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      appBar: AppBar(
        title: Text("Practical_8"),
      ),
      body: ListView(
        children: [
          ListTile(
            leading: Icon(Icons.star_border),
            title: Text("Star"),
          ),
          ListTile(
            leading: Icon(Icons.sunny),
            title: Text("Sun"),
          ),
          ListTile(
            leading: Icon(Icons.air),
            title: Text("Humidity"),
          ),
          ListTile(
            leading: Icon(Icons.location_on),
            title: Text("Location"),
          ),
          ListTile(
            leading: Icon(Icons.access_alarm_outlined),
            title: Text("Alaram"),
          ),ListTile(
            leading: Icon(Icons.bus_alert),
            title: Text("Bus"),
          ),
          ListTile(
            leading: Icon(Icons.car_crash),
            title: Text("Car"),
          ),
          ListTile(
            leading: Icon(Icons.mobile_screen_share),
            title: Text("Mobile"),
          ),
          ListTile(
            leading: Icon(Icons.icecream),
            title: Text("Icecream"),
          ),
          ListTile(
            leading: Icon(Icons.chair),
            title: Text("Chair"),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: Text("Home"),
          ),
          ListTile(
            leading: Icon(Icons.cloud),
            title: Text("Cloud"),
          ),
        ],
      ),
    ),
  ));
}
