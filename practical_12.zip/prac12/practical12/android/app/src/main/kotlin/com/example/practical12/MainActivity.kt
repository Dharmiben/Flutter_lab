package com.example.practical12

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
